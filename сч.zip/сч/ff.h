#pragma once
double Perimetr(double a,double b,double c);
double plowad6(double a, double b,double c);
double raBnoct(double a, double b, double c);

