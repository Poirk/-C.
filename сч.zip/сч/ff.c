#include <math.h>
#include <stdbool.h>
#include "ff.h"

double raBnoct(double a, double b, double c) {
    if (a + b <= c || a + c <= b || b + c <= a) {
        return false;
    } else {
        return true;
    }
}

double Perimetr(double a, double b, double c) {
    return a + b + c;
}

double plowad6(double a, double b, double c) {
    double p = Perimetr(a, b, c) / 2.0;
    return sqrt(p * (p - a) * (p - b) * (p - c));
}
