#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include "ff.h"
int main(){
	double a,b,c;
	printf("bbedite dlini storon\n");
	printf("a=");
	scanf("%lf",&a);
	printf("b=");
	scanf("%lf",&b);
	printf("c=");
	scanf("%lf",&c);
	if (raBnoct(a, b, c) == false) {
		printf("treygolnik_neveren");
	}
	else{
		printf("perimetr=%.2lf",Perimetr(a,b,c));
		printf("plowad=%.2lf",plowad6(a,b,c));
		
	}
	return 0;
}
